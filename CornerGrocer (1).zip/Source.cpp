#include <iostream>
#include <fstream>
#include <map>
#include <string>
using namespace std;

class ItemTracker {
private:
    //Map to store item frequencies
    map<string, int> itemFrequency;
    // Input and output file paths
    const string inputFile = "CS210_Project_Three_Input_File.txt";
    const string outputFile = "frequency.dat";

public:
    // Constructor to read input file and initialize item frequencies
    ItemTracker() {
        ReadInputFile();
    }

    // Function to read input file and update item frequencies
    void ReadInputFile() {
        ifstream file(inputFile);
        string item;

        // Read items from file and update frequencies in map
        while (file >> item) {
            itemFrequency[item]++;
        }

        file.close();
    }

    // Function to save item frequencies to output file
    void SaveFreqToFile() {
        ofstream file(outputFile);

        // Write item frequencies to file
        for (const auto& entry : itemFrequency) {
            file << entry.first << " " << entry.second << endl;
        }

        file.close();
    }

    // Function to print item frequencies
    void PrintFrequency() {
        for (const auto& entry : itemFrequency) {
            cout << entry.first << " " << entry.second << endl;
        }
    }

    // Function to print item frequencies as a histogram
    void PrintHist() {
        for (const auto& entry : itemFrequency) {
            cout << entry.first << " ";
            for (int i = 0; i < entry.second; ++i) {
                cout << "*";
            }
            cout << endl;
        }
    }

    // Function to run the item tracker program
    void RunProg() {
        int choice;
        while (true) {
            cout << "Menu Options:\n";
            cout << "1. Search for an item\n";
            cout << "2. Print frequency of all items\n";
            cout << "3. Print item frequencies as histogram\n";
            cout << "4. Exit\n";
            cout << "Please make a selection: ";
            cin >> choice;

            switch (choice) {
            case 1: {
                string item;
                cout << "Enter the item: ";
                cin >> item;
                cout << "Frequency of " << item << ": " << itemFrequency[item] << endl;
                break;
            }
            case 2: {
                PrintFrequency();
                break;
            }
            case 3: {
                PrintHist();
                break;
            }
            case 4: {
                SaveFreqToFile();
                cout << "Data saved to " << outputFile << ". Exiting...\n";
                return;
            }
            default: {
                cout << "Invalid. Please select an option from the list.\n";
                break;
            }
            }
        }
    }
};

// Main function to create ItemTracker object and run the program
int main() {
    ItemTracker tracker;
    tracker.RunProg();
    return 0;
}